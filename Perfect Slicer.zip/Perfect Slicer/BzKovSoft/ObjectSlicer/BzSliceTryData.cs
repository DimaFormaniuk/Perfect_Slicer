﻿using UnityEngine;

namespace BzKovSoft.ObjectSlicer
{
	public class BzSliceTryData
	{
		public IComponentManager componentManager;
		public Plane plane;
		public object addData;
	}

}