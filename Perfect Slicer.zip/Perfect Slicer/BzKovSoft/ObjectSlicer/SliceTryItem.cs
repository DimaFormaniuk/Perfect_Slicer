﻿using UnityEngine;

namespace BzKovSoft.ObjectSlicer
{
	public class SliceTryItem
	{
		public BzMeshDataDissector meshDissector;
		public Renderer meshRenderer;
		public SliceResult SliceResult;
	}
}