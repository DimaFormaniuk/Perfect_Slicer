﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Assembly-CSharp-Editor.dll.dll")]
[assembly: InternalsVisibleTo("Assembly-CSharp-Editor.dll")]
[assembly: InternalsVisibleTo("Assembly-CSharp-Editor")]